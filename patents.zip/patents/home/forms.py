from django import forms
from home.models import Dept1Info
from django.forms import ModelForm, Textarea


class HomeForm(forms.ModelForm):
    #post = forms.CharField()
    #deptinfo = forms.CharField()



    class Meta:
        model = Dept1Info
        #p = DeptInfo.objects.values('Title')
        #print(p)
        #fields = ['Title','Inventor_ID','Inventor_Name','Remarks']
        fields = '__all__'
        #exclude('deptname')
        widgets = {
            'Remarks': forms.Textarea(attrs={'cols': 80, 'rows': 10}),
        }