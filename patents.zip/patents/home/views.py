from django.views.generic import TemplateView
from django.shortcuts import render,redirect
from django.db.models import Q
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib import messages


from home.forms import HomeForm
from home.models import Dept1Info
from trial.models import Test
from django.utils import timezone

class HomeView(TemplateView):
    template_name = 'home/home.html'


    def get(self,request):
        form = HomeForm()
        deptinfo = Dept1Info.objects.all()
        #print(deptinfo)
        args = {'form':form, 'deptinfo': deptinfo}
        return render(request, self.template_name, {'form': form})

    @csrf_exempt
    def post(self, request):
        print("entered post method")
        if request.method == 'POST':
            form = HomeForm(request.POST, request.FILES)
            if form.is_valid():
                form.save()
                #return render_to_response('template_name', message='Save complete')
                messages.success(request, 'Your password was updated successfully!')
                #messages.info(request, 'Your patent has been submitted successfully!')
                return redirect('home:patent_list')
        else:
            form = HomeForm()
        return render(request, self.template_name, {'form': form})

def searchpatents(request):
    template = 'home/searchpatents.html'
    #args = ""
    #today = timezone.now().date()
    queryset_list = Dept1Info.objects.all() #.order_by("-timestamp")
    query = request.GET.get("q")
    if query:
        #print("entered if")
        queryset_list = queryset_list.filter(Q(Title__icontains=query))
        #print(Title__icontains)
    else:
        messages.error(request, 'No results Found')

    paginator = Paginator(queryset_list,2)
    page_request_var = "page"
    page = request.GET.get(page_request_var)
    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        queryset = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        queryset = paginator.page(paginator.num_pages)
    
    context = {
        "object_list": queryset,
        "page_request_var": page_request_var,
         }
    return render(request,template,context)


