from django.db import models


# Create your models here.
class Dept1Info(models.Model):
	Drop_Down_choices = (
			('Solution','Solution'),
			('Idea','Idea'),
			('Quality','Quality'),
		)
	deptname = models.CharField(max_length=200, unique=True)
	#projects = MultiSelectField(max_length=15, ch)
	datetime = models.DateTimeField(auto_now=True)
	Title = models.CharField(max_length=500)
	Inventor_ID = models.IntegerField()
	InventorName = models.CharField(max_length=500)
	Spotlighted_Problem = models.CharField(max_length=100,
                                      choices=Drop_Down_choices,
                                      default=None)
	Upload_Document = models.FileField(upload_to='documents/',default=None)
	Remarks = models.CharField(max_length=500,default=None)

