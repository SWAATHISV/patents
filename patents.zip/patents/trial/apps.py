from django.apps import AppConfig


class TrialConfig(AppConfig):
    name = 'trial'
