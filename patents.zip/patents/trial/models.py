from django.db import models

# Create your models here.
class Test(models.Model):
	deptname = models.CharField(max_length=200, unique=True)
	#projects = MultiSelectField(max_length=15, ch)
	datetime = models.DateTimeField(auto_now=True)
	Title = models.CharField(max_length=500)